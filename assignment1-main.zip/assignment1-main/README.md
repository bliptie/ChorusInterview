## SWEN301 Assignment 1 Template

To use the StudentManagerUI run these in the terminal:

``mvn package``

to fetch one student run:

```
java -jar target/studentfinder-1.0.0.jar -fetchone [insert id here]
```

to fetch all students run:

```
java -jar target/studentfinder-1.0.0.jar -fetchall
```

to export the file to a csv file run:

```
java -jar target/studentfinder-1.0.0.jar -export -f [insert name of file]
```


Garbage Collection:
My program is prone to memory leaks as the student and degree hashmaps used for caching are only cleared when explicitly told to (ie.
when running tests). Due to this it will eventually store the whole database and if there aren't frequent enough update calls then the
record being returned when queried will have incorrect values compared to the database and changes on the database side will not be
reflected in the cached results. The solution is to remove records from the cache when all references are gone.
