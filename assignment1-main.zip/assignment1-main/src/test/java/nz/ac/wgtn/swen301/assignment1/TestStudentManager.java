package nz.ac.wgtn.swen301.assignment1;

import nz.ac.wgtn.swen301.studentdb.Degree;
import nz.ac.wgtn.swen301.studentdb.NoSuchRecordException;
import nz.ac.wgtn.swen301.studentdb.Student;
import nz.ac.wgtn.swen301.studentdb.StudentDB;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Unit tests for StudentManager, to be extended.
 */
public class TestStudentManager {

    // DO NOT REMOVE THE FOLLOWING -- THIS WILL ENSURE THAT THE DATABASE IS AVAILABLE
    // AND IN ITS INITIAL STATE BEFORE EACH TEST RUNS
    @BeforeEach
    public  void init () {
        StudentDB.init();
        StudentManager.reset();
        
    }
    // DO NOT REMOVE BLOCK ENDS HERE

    @Test
    public void dummyTest() throws Exception {
        Student student = new StudentManager().fetchStudent("id42");
        // THIS WILL INITIALLY FAIL !!
        assertNotNull(student);
    }

    // Test for fetchStudent method
    @Test
    public void testFetchStudent() {
        assertThrows(NoSuchRecordException.class, () -> {
            Student student = new StudentManager().fetchStudent("");
        });
    }

    // Test for fetchStudent method
    @Test
    public void testFetchStudent2() throws NoSuchRecordException {
        Student student = new StudentManager().fetchStudent("id2");
    }

    // test for fetchDegree method
    @Test
    public void testFetchDegree() throws Exception {
        Degree degree = new StudentManager().fetchDegree("deg0");
        assertNotNull(degree);
    }

    // test remove method
    @Test
    public void testRemove() throws Exception {
        Student student = new Student("id42", "name", "first_name", new Degree("deg0", "degree_name"));
        StudentManager.remove(student);
        // fetch it and see if its been removed
        assertThrows(NoSuchRecordException.class, () -> {
            StudentManager.fetchStudent("id42");
        });
    }

    // test remove method where student doesn't exist
    @Test
    public void testRemove2() throws Exception{
        Student student = new Student("id42", "name", "first_name", new Degree("deg0", "degree_name"));
        StudentManager.remove(student);
        assertThrows(NoSuchRecordException.class, () -> {
            StudentManager.remove(student);
        });
    }

    // test update method
    @Test
    public void testUpdate() throws Exception {
        Student student = new Student("id42", "name", "first_name", new Degree("deg0", "degree_name"));
        StudentManager.update(student);
        // fetch it and see if its been updated
        Student s = StudentManager.fetchStudent("id42");
        Assertions.assertEquals(s, student);
    }

    // test update method if student doesn't exist
    @Test
    public void testUpdate2() throws Exception {
        Student student = new Student("id42", "name", "first_name", new Degree("deg0", "degree_name"));
        StudentManager.remove(student);
        assertThrows(NoSuchRecordException.class, () -> {
            StudentManager.update(student);
        });
    }

    // testPerformance test
    @Test
    @Timeout(1)
    public void testPerformance() throws Exception {
        long start = System.currentTimeMillis();
        // run the fetchStudent and fetchDegree method 500 times and time it
        for (int i = 0; i < 500; i++) {
            Student s = StudentManager.fetchStudent("id2");
            Degree d = StudentManager.fetchDegree("deg0");
        }
        long end = System.currentTimeMillis();
        long time = end - start;
        System.out.println("Time taken: " + time + "ms");
    }

    //test new student
    @Test
    public void testNewStudent() throws Exception {
        Student s = StudentManager.newStudent("Sam", "White", new Degree("deg0", "degree_name"));
        // fetch it and see if it exists
        Student student = StudentManager.fetchStudent(s.getId());
        assertNotNull(student);
    }


}
