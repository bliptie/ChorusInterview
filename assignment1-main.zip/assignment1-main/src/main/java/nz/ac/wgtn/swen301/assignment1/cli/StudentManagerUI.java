package nz.ac.wgtn.swen301.assignment1.cli;

import nz.ac.wgtn.swen301.assignment1.StudentManager;
import nz.ac.wgtn.swen301.studentdb.Degree;
import nz.ac.wgtn.swen301.studentdb.NoSuchRecordException;
import nz.ac.wgtn.swen301.studentdb.Student;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionGroup;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Collection;

public class StudentManagerUI {

    // THE FOLLOWING METHOD MUST BE IMPLEMENTED
    /**
     * Executable: the user will provide argument(s) and print details to the console as described in the assignment brief,
     * E.g. a user could invoke this by running "java -cp <someclasspath> <arguments></arguments>"
     * @param arg
     */
    public static void main (String[] arg){

        Options options = new Options();

        OptionGroup optionGroup = new OptionGroup();

        optionGroup.addOption(new Option("fetchone", true, "fetch a student record"));
        optionGroup.addOption(new Option("fetchall", false, "fetch all student records"));
        optionGroup.addOption(new Option("export", false, "export all student records"));
        options.addOptionGroup(optionGroup);

        options.addOption("f", "file", true, "file to export to");
        //define parser
        CommandLine cmd;
        CommandLineParser parser = new DefaultParser();

        try {
            cmd = parser.parse(options, arg);
            if(cmd.hasOption("fetchone")){
                Student s = StudentManager.fetchStudent("id" + cmd.getOptionValue("fetchone"));
                System.out.println(" ID: " + s.getId() + " Name: " + s.getFirstName() + " " + s.getName() +" Degree: "+ s.getDegree().getId());

            } else if(cmd.hasOption("fetchall")){
                System.out.println("made it");
                Collection<String> students = StudentManager.fetchAllStudentIds();
                for(String id: students){
                    Student s = StudentManager.fetchStudent(id);
                    System.out.println(" ID: " + s.getId() + " Name: " + s.getFirstName() + " " + s.getName() +" Degree: "+ s.getDegree().getId());
                }
            }else if(cmd.hasOption("export")){
                PrintWriter writer = new PrintWriter(new File(cmd.getOptionValue("f")+ ".csv"));
                Collection<String> students = StudentManager.fetchAllStudentIds();
                writer.println("id,first_name,name,degree");
                for(String id : students){
                    Student s = StudentManager.fetchStudent(id);
                    writer.println(s.getId() + "," + s.getFirstName() + "," + s.getName() + "," + s.getDegree().getId());
                }
                writer.close();
            }
        } catch (ParseException | NoSuchRecordException | FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }


    }
}